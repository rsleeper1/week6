import logging
import logstash
import sys
import time

logger = logging.getLogger("python-logstash-logger")
logger.setLevel(logging.INFO)
logger.addHandler(logstash.LogstashHandler("3.80.29.164", 5959, version=1))

x = 1
if(x == 1):
    logger.info("python-logstash: x is equal to one.")
else:
    logger.error("python-logstash: something went wrong.")

y = 2
if(y == 2):
    logger.warning("python-logstash: Warning, y = 2, which means y > x.")
else:
    logger.error("python-logstash: something went wrong.")

logger.error("python-logstash: I made this error on purpose.")

